require("andyterrify.remap")
require("andyterrify.settings")
-- require("andyterrify.autocommands")
require("andyterrify.lazy.init")
